import couchdb
import json
import math


url = "http://admin:admin@localhost:5984/"

server = couchdb.Server(url)

print(server)

database = server['test2']

query = {
   "selector": {
      "_id": "$sirs"
   }
}

result = database.find(query)

L = list(result)
data = L[0]["moduleDescriptions"]

listPositionable = []

def findPositionable(obj):
    for name in obj:
        if name == "filterValue":
            positionable = obj[name].split("fr.sirs.core.model.")[1]
            listPositionable.append(positionable)
        else:
            if type(obj[name]) == list:
                for item in obj[name]:
                    findPositionable(item)
            elif type(obj[name]) == dict:
                findPositionable(obj)

for name in data:
    findPositionable(data[name])

print("RESULT")
print(listPositionable)
print(len(listPositionable))
print("")

def simpleQuery(name):
    query = {
        "selector": {
            "@class": "fr.sirs.core.model." + name
        }
    }

    result = database.find(query)
    return result

classAttribute = {}

def computeColor(n):
    tot = 16 * 16
    if n <= 7:
        a = math.floor(n * tot / 7)
        b = math.floor((7 - n) * tot / 7)
        c = 16 * 16 - 1
    elif n <= 14:
        n = n - 7
        a = math.floor((7 - n) * tot / 7)
        b = 16 * 16 - 1
        c = math.floor(n * tot / 7)
    else:
        n = n - 14
        a = 16 * 16 - 1
        b = math.floor(n * tot / 7)
        c = math.floor((7 - n) * tot / 7)
    ha = hex(a).split('x')[1]
    hb = hex(b).split('x')[1]
    hc = hex(c).split('x')[1]
    return ha + hb + hc

for index in range(10):
    name = listPositionable[index]
    result = simpleQuery(name)
    if index <= 19:
        val = index
        symbol = "triangle"
        capstyle = "flat" # flat, square, round
        line_style = "solid" # solid, dash (or dashed)
        joinstyle = "miter" # miter, bevel, round
    elif index <= 39:
        val = index - 20
        symbol = "square"
        capstyle = "square"
        line_style = "solid"
        joinstyle = "bevel"
    elif index <= 59:
        val = index - 40
        symbol = "circle"
        capstyle = "round"
        line_style = "solid"
        joinstyle = "round"
    else:
        # point
        val = index - 60
        symbol = "cross"
        # line
        capstyle = "square"
        line_style = "dash"
        joinstyle = "bevel"
    color = computeColor(val)
    while len(color) != 6:
        color = '0' + color
    classAttribute[name] = {
        "attributes": [],
        "style": {
            "default": {
                "color": '#' + color,
                "width": "1.0",
                "capstyle": capstyle,
                "line_style": line_style,
                "joinstyle": joinstyle
            },
            "point": {
                "name": symbol,
                "color": '#' + color
            }
        },
        "crs": "EPSG:2154"
    }
    for item in result:
        for attr in item:
            if attr not in classAttribute[name]:
                classAttribute[name]["attributes"].append(attr)

for name in classAttribute:
    classAttribute[name]["attributes"].sort()
    up = classAttribute[name]["attributes"]
    classAttribute[name]["attributes"] = {}
    for ord in up:
        classAttribute[name]["attributes"][ord] = True
    print(name)
    print(classAttribute[name])

with open('next_configuration.json', 'w') as outfile:
    json.dump(classAttribute, outfile)

