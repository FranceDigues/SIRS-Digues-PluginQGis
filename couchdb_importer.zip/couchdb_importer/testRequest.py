import requests
import couchdb

#r = requests.get('https://github.com/timeline.json')

#print(r.json())

def filter():
    url = "http://localhost:5984/"
    target = []

    dbs = couchdb.Server(url + "_all_dbs")

    for db in dbs:
        print(db)
        r = requests.get(url + db)
        print(r.status_code)
        if r.status_code == 200:
            target.append(db)
    print(target)


if __name__=="__main__":
    filter()