import json

l = {}
data = None

with open('configuration.json') as json_file:
    data = json.load(json_file)

for name in data:
    l[name] = list(data[name]['attributes'])
    l[name].sort()

for name in data:
    data[name]['attributes'] = {}
    for attr in l[name]:
        data[name]['attributes'][attr] = True
    print(data[name]['attributes'])
    print("")

with open('configuration.json', 'w') as outfile:
    json.dump(data, outfile)
